from pwn import*
context(arch='amd64', os='linux', log_level='debug')
# 可能需要打 orw
code_len=0x774
stack_content_siz=0x19e
stack_offset=0x1000
init_stack_top=0x1900 # 是个随机数 那就随便赋值一个符合条件的就行
# get content from note.bin
f=open('note.bin','rb')
content=f.read()
f.close()
# get code
code=content[16:16+code_len]
stack_content=content[16+code_len:16+code_len+stack_content_siz]
# parse code to instructions
regs=["%0","%1","%2","%3","%4","%5","%6","%7","%8","%9","rip","rbp","sp"]
sizes=["char","word","dword","qword"]
def push_reg(idx):
    return "push "+regs[idx]
def ld_with_siz(siz,idx,idx2):
    return "ld "+sizes[siz-1]+" "+regs[idx]+" <- stack[ "+regs[idx2]+" ]"
def nop():
    return "nop"
def read_to_reg(siz,reg_idx):
    if siz==0:
        return "read "+regs[reg_idx]+" <- char"
    elif siz==1:
        return "read "+regs[reg_idx]+" <- dword"
    elif siz==2:
        return "read "+regs[reg_idx]+" <- dword"
    else:
        return "read stack["+regs[reg_idx]+"] <- char"
def leave():
    return "leave"
def sub(siz,reg_idx,imm):
    if siz<=4 and siz>0:
        return "sub "+sizes[siz-1]+" "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+hex(imm)
    else:
        return "sub "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+regs[imm]
def op6():
    return ""
def add(siz,reg_idx,imm):
    if siz<=4 and siz>0:
        return "add "+sizes[siz-1]+" "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+hex(imm)
    else:
        return "add "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+regs[imm]
def store_2stack(siz,imm,reg_idx):
    if siz==1:
        return "store stack["+hex(imm)+"] <- "+regs[reg_idx]+" : char"
    elif siz==2:
        return "store stack["+hex(imm)+"] <- "+regs[reg_idx]+" : word"
    elif siz==3:
        return "store stack["+hex(imm)+"] <- "+regs[reg_idx]+" : dword"
    elif siz==4:
        return "store stack["+hex(imm)+"] <- "+regs[reg_idx]+" : qword"
    else:
        return ""
def store_2stack2(siz,reg_idx,reg_idx2):
    if siz==1:
        return "store stack["+regs[reg_idx2]+"] <- "+regs[reg_idx]+" : char"
    elif siz==2:
        return "store stack["+regs[reg_idx2]+"] <- "+regs[reg_idx]+" : word"
    elif siz==3:
        return "store stack["+regs[reg_idx2]+"] <- "+regs[reg_idx]+" : dword"
    elif siz==4:
        return "store stack["+regs[reg_idx2]+"] <- "+regs[reg_idx]+" : qword"
    else:
        return ""
def ld_reg(siz,reg_idx,imm):
    if siz==1:
        return "ld char "+regs[reg_idx]+" <- stack["+hex(imm)+"]"
    elif siz==2:
        return "ld word "+regs[reg_idx]+" <- stack["+hex(imm)+"]"
    elif siz==3:
        return "ld dword "+regs[reg_idx]+" <- stack["+hex(imm)+"]"
    elif siz==4:
        return "ld qword "+regs[reg_idx]+" <- stack["+hex(imm)+"]"
    else:
        return ""
def my_cmp(siz,reg_idx,imm):
    if siz:
        return "cmp "+regs[reg_idx]+" , "+(hex(u64(imm)))
    else:
        return "cmp "+regs[reg_idx]+" , "+regs[imm]
def my_exit():
    return "exit"
def my_and(siz,reg_idx,imm):
    # 按照前面 add,sub 的写法
    if siz<=4 and siz>0:
        return "and "+sizes[siz-1]+" "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+hex(imm)
    else:
        return "and "+regs[reg_idx]+" , "+regs[imm]
def decl(reg_idx):
    return "decl "+regs[reg_idx]
def div(siz,reg_idx,imm):
    if siz<=4 and siz>0:
        return "div "+sizes[siz-1]+" "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+hex(imm)
    else:
        return "div "+regs[reg_idx]+" , "+regs[imm]
def indir_jmp(siz,reg_idx):
    if siz==1:
        return "jez "+regs[reg_idx]
    elif siz==2:
        return "jnez "+regs[reg_idx]
    elif siz==3:
        return "jlt "+regs[reg_idx]
    elif siz==4:
        return "jgt "+regs[reg_idx]
    else:
        return "jmp "+regs[reg_idx]

def call(siz,val):
    if siz:
        return "call "+hex(u32(val))
    else:
        return "call "+regs[val]

def incl(reg_idx):
    return "incl "+regs[reg_idx]

def jmp_cond(siz,imm):
    if siz==1:
        return "jez "+hex(u32(imm))
    elif siz==2:
        return "jnez "+hex(u32(imm))
    elif siz==3:
        return "jlt "+hex(u32(imm))
    elif siz==4:
        return "jgt "+hex(u32(imm))
    else:
        return "jmp "+hex(u32(imm))
def pop(reg_idx):
    return "pop "+regs[reg_idx]

def my_or(siz,reg_idx,imm):
    if siz<=4 and siz>0:
        return "or "+sizes[siz-1]+" "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+hex(imm)
    else:
        return "or "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+regs[imm]

def assign(siz,reg_idx,imm):
    if siz<=4 and siz>0:
        return "mov "+sizes[siz-1]+" "+regs[reg_idx]+" , "+hex(imm)
    else:
        return "mov "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+regs[imm]

def print_reg(siz,reg_idx):
    if siz==0:
        return "print char "+regs[reg_idx]
    elif siz==1:
        return "print dword "+regs[reg_idx]
    elif siz==2:
        return "print qword "+regs[reg_idx]
    else:
        return "print stack["+regs[reg_idx]+"]"

def ret():
    return "ret"

def do_linked_list(siz):
    if siz==0:
        return "time((time_t *)regs_1)"
    elif siz==1:
        return "srand((unsigned int)regs_1)"
    elif siz==2:
        return "rand()"
    elif siz==3:
        return "regs[0] = insert_siz((size_t)regs_1)"
    elif siz==4:
        return "remove_ptr((void *)regs_1)"
    elif siz==5: # 感觉和 load 差不多hh
        return "regs[0] = (int)atol((const char *)&stack[(unsigned int)regs_1])"
    elif siz==6: # **vuln**
        return "read(0, regs_1, regs_2_siz)"
    elif siz==7:
        return "show regs_1 content" # "content: "
    else:
        return ""

def reset():
    return "reset"

def test(reg_idx,reg_idx1):
    return "test "+regs[reg_idx]+" , "+regs[reg_idx1]
def mul(siz,reg_idx,imm):
    if siz<=4 and siz>0:
        return "mul "+sizes[siz-1]+" "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+hex(imm)
    else:
        return "mul "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+regs[imm]
def my_xor(siz,reg_idx,imm):
    if siz<=4 and siz>0:
        return "xor "+sizes[siz-1]+" "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+hex(imm)
    else:
        return "xor "+regs[reg_idx]+" , "+regs[reg_idx]+" , "+regs[imm]

idx=0
s=""
while idx<code_len:
    op=code[idx]&0x1f
    s+=hex(idx)+": "
    siz=(code[idx]>>5)&0x7
    if op==0:
        s+=push_reg(code[idx+1])
        idx+=2
    elif op==1:
        s+=(ld_with_siz(siz,code[idx+1],code[idx+2]))
        idx+=3
    elif op==2:
        s+=(nop())
        idx+=1 
    elif op==3:
        s+=(read_to_reg(siz,code[idx+1]))
        idx+=2
    elif op==4:
        s+=(leave())
        idx+=1
    elif op==5:
        if siz==1:
            s+=(sub(siz,code[idx+1],code[idx+2]))
            idx+=3
        elif siz==2:
            s+=(sub(siz,code[idx+1],u16(code[idx+2:idx+4])))
            idx+=4
        elif siz==3:
            s+=(sub(siz,code[idx+1],u32(code[idx+2:idx+6])))
            idx+=6
        elif siz==4:
            s+=(sub(siz,code[idx+1],u64(code[idx+2:idx+10])))
            idx+=10
        else:
            s+=(sub(siz,code[idx+1],code[idx+2]))
            idx+=3
    elif op==6:
        s+=(op6())
        idx+=1
    elif op==7:
        if siz==1:
            s+=(add(siz,code[idx+1],code[idx+2]))
            idx+=3
        elif siz==2:
            s+=(add(siz,code[idx+1],u16(code[idx+2:idx+4])))
            idx+=4
        elif siz==3:
            s+=(add(siz,code[idx+1],u32(code[idx+2:idx+6])))
            idx+=6
        elif siz==4:
            s+=(add(siz,code[idx+1],u64(code[idx+2:idx+10])))
            idx+=10
        else:
            s+=(add(siz,code[idx+1],code[idx+2]))
            idx+=3
    elif op==8:
        s+=(store_2stack(siz,code[idx+1],code[idx+2:idx+6]))
        idx+=6
    elif op==9:
        s+=(store_2stack2(siz,code[idx+1],code[idx+2]))
        idx+=3
    elif op==10:
        s+=(ld_reg(siz,code[idx+1],code[idx+2:idx+6]))
        idx+=6
    elif op==11:
        if siz:
            s+=(my_cmp(siz,code[idx+1],code[idx+2:idx+10]))
            idx+=10
        else:
            s+=(my_cmp(siz,code[idx+1],code[idx+2]))
            idx+=3
    elif op==12:
        s+=(my_exit())
        idx+=1
    elif op==13:
        if siz==1:
            s+=(my_and(siz,code[idx+1],code[idx+2]))
            idx+=3
        elif siz==2:
            s+=(my_and(siz,code[idx+1],u16(code[idx+2:idx+4])))
            idx+=4
        elif siz==3:
            s+=(my_and(siz,code[idx+1],u32(code[idx+2:idx+6])))
            idx+=6
        elif siz==4:
            s+=(my_and(siz,code[idx+1],u64(code[idx+2:idx+10])))
            idx+=10
        else:
            s+=(my_and(siz,code[idx+1],code[idx+2]))
            idx+=3
    elif op==14:
        s+=(decl(code[idx+1]))
        idx+=2
    elif op==15:
        # div 的写法和其他一样
        if siz==1:
            s+=(div(siz,code[idx+1],code[idx+2]))
            idx+=3
        elif siz==2:
            s+=(div(siz,code[idx+1],u16(code[idx+2:idx+4])))
            idx+=4
        elif siz==3:
            s+=(div(siz,code[idx+1],u32(code[idx+2:idx+6])))
            idx+=6
        elif siz==4:
            s+=(div(siz,code[idx+1],u64(code[idx+2:idx+10])))
            idx+=10
        else:
            s+=(div(siz,code[idx+1],code[idx+2]))
            idx+=3
    elif op==16:
        s+=(indir_jmp(siz,code[idx+1]))
        idx+=2
    elif op==17:
        if siz:
            s+=(call(siz,code[idx+1:idx+5]))
            idx+=5
        else:
            s+=(call(siz,code[idx+1]))
            idx+=2
    
    elif op==18:
        s+=(incl(code[idx+1]))
        idx+=2
    elif op==19:
        s+=(jmp_cond(siz,code[idx+1:idx+5]))
        idx+=5
    elif op==20:
        s+=(pop(code[idx+1]))
        idx+=2
    elif op==21:
        # my_or 的写法和 my_and 一样
        if siz==1:
            s+=(my_or(siz,code[idx+1],code[idx+2]))
            idx+=3
        elif siz==2:
            s+=(my_or(siz,code[idx+1],u16(code[idx+2:idx+4])))
            idx+=4
        elif siz==3:
            s+=(my_or(siz,code[idx+1],u32(code[idx+2:idx+6])))
            idx+=6
        elif siz==4:
            s+=(my_or(siz,code[idx+1],u64(code[idx+2:idx+10])))
            idx+=10
        else:
            s+=(my_or(siz,code[idx+1],code[idx+2]))
            idx+=3
    elif op==22:
        # assign 的写法和其他一样
        if siz==1:
            s+=(assign(siz,code[idx+1],code[idx+2]))
            idx+=3
        elif siz==2:
            s+=(assign(siz,code[idx+1],u16(code[idx+2:idx+4])))
            idx+=4
        elif siz==3:
            s+=(assign(siz,code[idx+1],u32(code[idx+2:idx+6])))
            idx+=6
        elif siz==4:
            s+=(assign(siz,code[idx+1],u64(code[idx+2:idx+10])))
            idx+=10
        else:
            s+=(assign(siz,code[idx+1],code[idx+2]))
            idx+=3
    elif op==23:
        s+=(print_reg(siz,code[idx+1]))
        idx+=2
    elif op==24:
        s+=(ret())
        idx+=1
    elif op==25:
        s+=(do_linked_list(siz))
        idx+=1
    elif op==26:
        s+=(reset())
        idx+=1
    elif op==27:
        s+=(test(code[idx+1],code[idx+2]))
        idx+=3
    elif op==28:
        # mul 和 div 一样
        if siz==1:
            s+=(mul(siz,code[idx+1],code[idx+2]))
            idx+=3
        elif siz==2:
            s+=(mul(siz,code[idx+1],u16(code[idx+2:idx+4])))
            idx+=4
        elif siz==3:
            s+=(mul(siz,code[idx+1],u32(code[idx+2:idx+6])))
            idx+=6
        elif siz==4:
            s+=(mul(siz,code[idx+1],u64(code[idx+2:idx+10])))
            idx+=10
        else:
            s+=(mul(siz,code[idx+1],code[idx+2]))
            idx+=3
    elif op==29:
        # xor 和 or 一样
        if siz==1:
            s+=(my_xor(siz,code[idx+1],code[idx+2]))
            idx+=3
        elif siz==2:
            s+=(my_xor(siz,code[idx+1],u16(code[idx+2:idx+4])))
            idx+=4
        elif siz==3:
            s+=(my_xor(siz,code[idx+1],u32(code[idx+2:idx+6])))
            idx+=6
        elif siz==4:
            s+=(my_xor(siz,code[idx+1],u64(code[idx+2:idx+10])))
            idx+=10
        else:
            s+=(my_xor(siz,code[idx+1],code[idx+2]))
            idx+=3
    else:
        s+="error"
        break
    s+="\n"

f=open('code.txt','w')
f.write(s)
# print stack
idx=0
s=""
for i in range(0,stack_content_siz,8):
    s+=hex(init_stack_top+stack_offset+i)+": "+hex(u64(stack_content[i:min(i+8,stack_content_siz)].ljust(8,b"\x00")))+"  "+stack_content[i:min(i+8,stack_content_siz)].decode("latin-1")+"\n"
f1=open('stack.txt','w')
f1.write(s)