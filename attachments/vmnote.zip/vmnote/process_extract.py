from pwn import*
f=open("extract_stack","r")
# readlines of f
lines=f.readlines()
# close f
f.close()
# open file "extracted_stack" in write mode
f=open("extracted_stack","w")
# for each line in lines
for line in lines:
    # get the three ints
    a, b, c = map(lambda x: int(x.rstrip(':'), 16), line.split())
    # write the three ints to f
    a=a%0x1000-0xe0
    d=p64(b)
    e=p64(c)
    f.write(hex(a)+"   "+hex(b)+"   "+hex(c)+"   "+d.decode("latin-1")+" "+e.decode("latin-1")+"\n")
f.close()