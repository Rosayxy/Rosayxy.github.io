# 分别读出 stack 0x1120 0x101f 的部分
f=open("extract_stack","r")
lines=f.readlines()
s=[0xda]
cnt=1
for line in lines[2:10]:
    a, b, c = map(lambda x: int(x.rstrip(':'), 16), line.split())
    for i in range(8):
        s.append(b&0xff)
        b>>=8
    for i in range(8):
        s.append(c&0xff)
        c>>=8
# print x in the format of the list with each number is a hex
print([hex(x) for x in s])